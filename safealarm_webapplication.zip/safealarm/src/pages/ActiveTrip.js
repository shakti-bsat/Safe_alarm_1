import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Shield, XCircle } from 'lucide-react';
import { useTrip, TRIP_STATUS } from '../context/TripContext';
import './ActiveTrip.css';

function formatTime(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

export default function ActiveTrip() {
  const { status, secondsLeft, etaTime, tripSettings, startTime, location, triggerEmergency, resetTrip } = useTrip();
  const navigate = useNavigate();

  useEffect(() => {
    if (status === TRIP_STATUS.IDLE) navigate('/');
    if (status === TRIP_STATUS.CONFIRMING || status === TRIP_STATUS.SNOOZED) navigate('/confirm');
    if (status === TRIP_STATUS.EMERGENCY || status === TRIP_STATUS.ESCALATED) navigate('/emergency');
    if (status === TRIP_STATUS.SAFE) navigate('/safe');
  }, [status, navigate]);

  const totalSeconds = tripSettings.durationMinutes * 60;
  const progress = totalSeconds > 0 ? (secondsLeft / totalSeconds) : 0;
  const circumference = 2 * Math.PI * 90;
  const offset = circumference * (1 - progress);

  const percent = Math.round(progress * 100);

  return (
    <div className="active-trip fade-in">
      <div className="active-header">
        <span className="badge badge-safe"><span className="dot dot-safe" />MONITORING ACTIVE</span>
      </div>

      <div className="timer-ring-wrapper">
        <svg className="timer-ring" viewBox="0 0 200 200">
          <circle className="ring-bg" cx="100" cy="100" r="90" />
          <circle
            className="ring-progress"
            cx="100" cy="100" r="90"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ stroke: percent > 30 ? 'var(--safe)' : percent > 10 ? 'var(--warn)' : 'var(--danger)' }}
          />
        </svg>
        <div className="timer-content">
          <div className="timer-value">{formatTime(secondsLeft)}</div>
          <div className="timer-label">until ETA</div>
        </div>
      </div>

      <div className="trip-info card">
        <div className="info-row">
          <MapPin size={14} />
          <span className="info-key">Destination</span>
          <span className="info-val">{tripSettings.destination}</span>
        </div>
        <div className="info-row">
          <Shield size={14} />
          <span className="info-key">ETA</span>
          <span className="info-val">
            {etaTime ? etaTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
          </span>
        </div>
        <div className="info-row">
          <span className="dot dot-safe" style={{ marginLeft: 0 }} />
          <span className="info-key">Started</span>
          <span className="info-val">
            {startTime ? startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
          </span>
        </div>
        {location && (
          <div className="info-row">
            <MapPin size={14} />
            <span className="info-key">GPS</span>
            <a
              href={`https://maps.google.com/?q=${location.lat},${location.lng}`}
              target="_blank"
              rel="noreferrer"
              className="info-link"
            >
              View on Maps
            </a>
          </div>
        )}
      </div>

      <div className="active-actions">
        <button className="btn btn-danger emer-btn" onClick={() => { triggerEmergency(); navigate('/emergency'); }}>
          <XCircle size={20} />
          EMERGENCY
        </button>
        <button className="btn btn-ghost cancel-btn" onClick={() => { resetTrip(); navigate('/'); }}>
          Cancel Trip
        </button>
      </div>

      <p className="monitoring-note">
        You'll be prompted to confirm arrival when your ETA expires.
        If you don't respond, trusted contacts will be alerted automatically.
      </p>
    </div>
  );
}
