import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';

const TripContext = createContext(null);

export const TRIP_STATUS = {
  IDLE: 'idle',
  ACTIVE: 'active',
  CONFIRMING: 'confirming',
  SNOOZED: 'snoozed',
  SAFE: 'safe',
  EMERGENCY: 'emergency',
  ESCALATED: 'escalated',
};

const SNOOZE_WINDOWS = [5 * 60, 3 * 60, 2 * 60]; // seconds

export function TripProvider({ children }) {
  const [status, setStatus] = useState(TRIP_STATUS.IDLE);
  const [contacts, setContacts] = useState([
    { id: 1, name: 'Priya Sharma', phone: '+91 98765 43210', relation: 'Sister', tier: 1 },
    { id: 2, name: 'Rajesh Kumar', phone: '+91 87654 32109', relation: 'Manager', tier: 2 },
  ]);
  const [tripSettings, setTripSettings] = useState({ destination: '', durationMinutes: 30 });
  const [startTime, setStartTime] = useState(null);
  const [etaTime, setEtaTime] = useState(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [snoozeIndex, setSnoozeIndex] = useState(0);
  const [snoozeSecondsLeft, setSnoozeSecondsLeft] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const [location, setLocation] = useState(null);
  const [sessionLog, setSessionLog] = useState([]);
  const [battery, setBattery] = useState(87);
  const [acknowledged, setAcknowledged] = useState(false);
  const [alertSentTime, setAlertSentTime] = useState(null);
  const [ackTime, setAckTime] = useState(null);

  const intervalRef = useRef(null);
  const snoozeIntervalRef = useRef(null);

  const log = useCallback((msg) => {
    setSessionLog(prev => [...prev, { time: new Date(), msg }]);
  }, []);

  // Get GPS location
  const getLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => setLocation({ lat: 12.9716, lng: 77.5946 }) // fallback: Bangalore
      );
    } else {
      setLocation({ lat: 12.9716, lng: 77.5946 });
    }
  }, []);

  // Simulate battery drain
  useEffect(() => {
    if (status === TRIP_STATUS.ACTIVE || status === TRIP_STATUS.SNOOZED) {
      const t = setInterval(() => setBattery(b => Math.max(b - 0.05, 0)), 10000);
      return () => clearInterval(t);
    }
  }, [status]);

  const startTrip = useCallback((settings) => {
    const now = new Date();
    const eta = new Date(now.getTime() + settings.durationMinutes * 60 * 1000);
    setTripSettings(settings);
    setStartTime(now);
    setEtaTime(eta);
    setSecondsLeft(settings.durationMinutes * 60);
    setSnoozeIndex(0);
    setAlerts([]);
    setAcknowledged(false);
    setAlertSentTime(null);
    setAckTime(null);
    setSessionLog([]);
    setStatus(TRIP_STATUS.ACTIVE);
    getLocation();
    log(`Trip started. ETA: ${eta.toLocaleTimeString()}`);
  }, [getLocation, log]);

  // Main countdown
  useEffect(() => {
    if (status === TRIP_STATUS.ACTIVE) {
      intervalRef.current = setInterval(() => {
        setSecondsLeft(prev => {
          if (prev <= 1) {
            clearInterval(intervalRef.current);
            setStatus(TRIP_STATUS.CONFIRMING);
            log('ETA lapsed — confirmation screen shown');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(intervalRef.current);
    }
  }, [status, log]);

  // Snooze countdown
  useEffect(() => {
    if (status === TRIP_STATUS.SNOOZED) {
      const window = SNOOZE_WINDOWS[snoozeIndex] || 60;
      setSnoozeSecondsLeft(window);
      snoozeIntervalRef.current = setInterval(() => {
        setSnoozeSecondsLeft(prev => {
          if (prev <= 1) {
            clearInterval(snoozeIntervalRef.current);
            const nextIndex = snoozeIndex + 1;
            if (nextIndex >= SNOOZE_WINDOWS.length) {
              // Auto escalate
              setStatus(TRIP_STATUS.EMERGENCY);
              log('Auto-escalation triggered — no response after all snooze windows');
              dispatchAlert('Auto-escalation: No response after final snooze window');
            } else {
              setSnoozeIndex(nextIndex);
              setStatus(TRIP_STATUS.CONFIRMING);
              log(`Snooze expired. Showing confirmation again (window ${nextIndex + 1})`);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(snoozeIntervalRef.current);
    }
  }, [status, snoozeIndex]); // eslint-disable-line

  const dispatchAlert = useCallback((reason) => {
    const now = new Date();
    setAlertSentTime(now);
    const loc = location || { lat: 12.9716, lng: 77.5946 };
    const alert = {
      id: Date.now(),
      time: now,
      reason,
      location: loc,
      mapsLink: `https://maps.google.com/?q=${loc.lat},${loc.lng}`,
      contacts: contacts.filter(c => c.tier === 1),
      acknowledged: false,
    };
    setAlerts(prev => [...prev, alert]);
    log(`Alert dispatched: "${reason}"`);

    // Simulate auto-acknowledgment after ~2.5 min for demo
    setTimeout(() => {
      setAcknowledged(true);
      setAckTime(new Date());
      setAlerts(prev => prev.map(a => a.id === alert.id ? { ...a, acknowledged: true } : a));
      log('Alert acknowledged by Tier 1 contact');
    }, 15000); // 15s in demo = represents 2.5 min
  }, [contacts, location, log]);

  const confirmSafe = useCallback(() => {
    setStatus(TRIP_STATUS.SAFE);
    log('User confirmed safe arrival');
  }, [log]);

  const snooze = useCallback(() => {
    setStatus(TRIP_STATUS.SNOOZED);
    log(`Snooze pressed (window ${snoozeIndex + 1} of ${SNOOZE_WINDOWS.length})`);
  }, [snoozeIndex]);

  const triggerEmergency = useCallback(() => {
    setStatus(TRIP_STATUS.EMERGENCY);
    dispatchAlert('User pressed EMERGENCY button');
    log('Emergency button pressed');
  }, [dispatchAlert, log]);

  const resetTrip = useCallback(() => {
    clearInterval(intervalRef.current);
    clearInterval(snoozeIntervalRef.current);
    setStatus(TRIP_STATUS.IDLE);
    setSecondsLeft(0);
    setSnoozeIndex(0);
  }, []);

  const acknowledgeAlert = useCallback((alertId) => {
    setAcknowledged(true);
    setAckTime(new Date());
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, acknowledged: true } : a));
    log('Alert manually acknowledged');
  }, [log]);

  return (
    <TripContext.Provider value={{
      status, contacts, setContacts, tripSettings, startTime, etaTime,
      secondsLeft, snoozeIndex, snoozeSecondsLeft, alerts, location,
      sessionLog, battery, acknowledged, alertSentTime, ackTime,
      startTrip, confirmSafe, snooze, triggerEmergency, resetTrip,
      acknowledgeAlert, SNOOZE_WINDOWS,
    }}>
      {children}
    </TripContext.Provider>
  );
}

export function useTrip() {
  const ctx = useContext(TripContext);
  if (!ctx) throw new Error('useTrip must be within TripProvider');
  return ctx;
}
