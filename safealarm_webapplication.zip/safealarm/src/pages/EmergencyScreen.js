import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertOctagon, MapPin, Clock, CheckCircle, ExternalLink } from 'lucide-react';
import { useTrip, TRIP_STATUS } from '../context/TripContext';
import './EmergencyScreen.css';

export default function EmergencyScreen() {
  const { status, alerts, contacts, location, resetTrip, acknowledged, alertSentTime, ackTime, acknowledgeAlert } = useTrip();
  const navigate = useNavigate();
  const [secondsSinceAlert, setSecondsSinceAlert] = useState(0);

  useEffect(() => {
    if (status === TRIP_STATUS.IDLE) navigate('/');
    if (status === TRIP_STATUS.SAFE) navigate('/safe');
  }, [status, navigate]);

  useEffect(() => {
    if (!alertSentTime) return;
    const t = setInterval(() => {
      setSecondsSinceAlert(Math.floor((Date.now() - alertSentTime.getTime()) / 1000));
    }, 1000);
    return () => clearInterval(t);
  }, [alertSentTime]);

  const latestAlert = alerts[alerts.length - 1];
  const tier1 = contacts.filter(c => c.tier === 1);
  const tier2 = contacts.filter(c => c.tier === 2);

  return (
    <div className="emergency fade-in">
      <div className="emer-icon-wrap">
        <AlertOctagon size={44} className="emer-icon" />
        <span className="e-ring" />
        <span className="e-ring r2" />
        <span className="e-ring r3" />
      </div>

      <h1 className="emer-title">ALERT DISPATCHED</h1>
      <p className="emer-sub">Trusted contacts have been notified with your location</p>

      <div className={`ack-status ${acknowledged ? 'acked' : 'waiting'}`}>
        {acknowledged ? (
          <>
            <CheckCircle size={18} />
            <div>
              <div className="ack-label">Acknowledged</div>
              <div className="ack-meta">
                {ackTime && alertSentTime
                  ? `${Math.round((ackTime - alertSentTime) / 1000)}s after alert`
                  : 'Contact confirmed receipt'}
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="ack-spinner" />
            <div>
              <div className="ack-label">Awaiting acknowledgment</div>
              <div className="ack-meta">
                {alertSentTime ? `${secondsSinceAlert}s elapsed` : 'Alert sent'}
                {secondsSinceAlert > 180 && ' — escalating to Tier 2'}
              </div>
            </div>
          </>
        )}
      </div>

      <div className="card alert-details">
        <div className="card-title"><Clock size={12} /> Alert Timeline</div>
        <div className="timeline">
          <div className="tl-item done">
            <div className="tl-dot" />
            <div className="tl-content">
              <div className="tl-label">Alert dispatched to Tier 1</div>
              <div className="tl-time">{alertSentTime?.toLocaleTimeString()}</div>
            </div>
          </div>
          <div className={`tl-item ${acknowledged ? 'done' : 'pending'}`}>
            <div className="tl-dot" />
            <div className="tl-content">
              <div className="tl-label">Acknowledgment received</div>
              <div className="tl-time">{acknowledged ? ackTime?.toLocaleTimeString() : 'Pending...'}</div>
            </div>
          </div>
          <div className={`tl-item ${secondsSinceAlert > 180 ? 'done' : 'pending'}`}>
            <div className="tl-dot" />
            <div className="tl-content">
              <div className="tl-label">Tier 2 escalation</div>
              <div className="tl-time">{secondsSinceAlert > 180 ? 'Activated' : 'After 3 min if no ack'}</div>
            </div>
          </div>
        </div>
      </div>

      {location && (
        <div className="card location-card">
          <div className="card-title"><MapPin size={12} /> Shared Location</div>
          <p className="loc-coords">{location.lat.toFixed(5)}, {location.lng.toFixed(5)}</p>
          <a
            href={`https://maps.google.com/?q=${location.lat},${location.lng}`}
            target="_blank"
            rel="noreferrer"
            className="btn btn-ghost btn-sm loc-link"
          >
            <ExternalLink size={14} />
            Open in Google Maps
          </a>
        </div>
      )}

      <div className="card contacts-alerted">
        <div className="card-title">Contacts Alerted</div>
        {[...tier1, ...tier2].map(c => (
          <div key={c.id} className="alerted-row">
            <div className="contact-avatar">{c.name[0]}</div>
            <div>
              <div className="contact-name">{c.name}</div>
              <div className="contact-meta">{c.phone} • Tier {c.tier}</div>
            </div>
            <span className={`badge badge-${c.tier === 1 ? 'danger' : 'warn'}`}>
              {c.tier === 1 ? 'ALERTED' : (secondsSinceAlert > 180 ? 'ESCALATED' : 'STANDBY')}
            </span>
          </div>
        ))}
      </div>

      {/* Simulate contact acknowledging */}
      {!acknowledged && latestAlert && (
        <button
          className="btn btn-ghost btn-sm"
          onClick={() => acknowledgeAlert(latestAlert.id)}
          style={{ marginBottom: 12 }}
        >
          [Demo] Simulate Contact Acknowledgment
        </button>
      )}

      <button className="btn btn-ghost" onClick={() => { resetTrip(); navigate('/'); }}>
        End Session & Return Home
      </button>
    </div>
  );
}
