import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Play, AlertTriangle, CheckCircle, Clock, Users } from 'lucide-react';
import { useTrip, TRIP_STATUS } from '../context/TripContext';
import './Dashboard.css';

export default function Dashboard() {
  const { status, sessionLog, contacts, alerts } = useTrip();
  const navigate = useNavigate();

  useEffect(() => {
    if (status === TRIP_STATUS.ACTIVE) navigate('/active');
    if (status === TRIP_STATUS.CONFIRMING || status === TRIP_STATUS.SNOOZED) navigate('/confirm');
    if (status === TRIP_STATUS.EMERGENCY || status === TRIP_STATUS.ESCALATED) navigate('/emergency');
    if (status === TRIP_STATUS.SAFE) navigate('/safe');
  }, [status, navigate]);

  const now = new Date();
  const hour = now.getHours();
  const isNightWindow = hour >= 20 || hour < 6;

  return (
    <div className="dashboard fade-in">
      <div className="dashboard-hero">
        <div className={`shield-icon ${isNightWindow ? 'night' : ''}`}>
          <Shield size={40} />
          {isNightWindow && <span className="shield-ring" />}
          {isNightWindow && <span className="shield-ring ring2" />}
        </div>
        <h1 className="hero-title">SafeAlarm</h1>
        <p className="hero-sub">Proactive arrival monitoring for night commuters</p>
        {isNightWindow && (
          <div className="night-banner">
            <AlertTriangle size={14} />
            Night monitoring window active (8PM–6AM)
          </div>
        )}
      </div>

      <div className="card stat-grid">
        <div className="stat">
          <Users size={18} />
          <span className="stat-val">{contacts.length}</span>
          <span className="stat-label">Trusted Contacts</span>
        </div>
        <div className="stat">
          <CheckCircle size={18} />
          <span className="stat-val">{alerts.filter(a => a.acknowledged).length}</span>
          <span className="stat-label">Acknowledged Alerts</span>
        </div>
        <div className="stat">
          <Clock size={18} />
          <span className="stat-val">&lt;7m</span>
          <span className="stat-label">Target Response</span>
        </div>
      </div>

      <button className="btn btn-primary start-btn" onClick={() => navigate('/setup')}>
        <Play size={18} />
        Start Trip Monitoring
      </button>

      <button className="btn btn-ghost" onClick={() => navigate('/contacts')}>
        <Users size={16} />
        Manage Trusted Contacts
      </button>

      {sessionLog.length > 0 && (
        <div className="card log-card">
          <div className="card-title">Session Log</div>
          {[...sessionLog].reverse().slice(0, 5).map((l, i) => (
            <div key={i} className="log-entry">
              <span className="log-time">{l.time.toLocaleTimeString()}</span>
              <span className="log-msg">{l.msg}</span>
            </div>
          ))}
        </div>
      )}

      <div className="card info-card">
        <div className="card-title">How it works</div>
        {[
          ['1', 'Start monitoring before your commute'],
          ['2', 'System tracks until your ETA expires'],
          ['3', 'Confirm safe arrival with one tap'],
          ['4', 'If no response, trusted contacts are auto-alerted'],
        ].map(([n, t]) => (
          <div key={n} className="how-step">
            <span className="step-num">{n}</span>
            <span>{t}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
