import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { TripProvider } from './context/TripContext';
import Dashboard from './pages/Dashboard';
import SetupTrip from './pages/SetupTrip';
import ActiveTrip from './pages/ActiveTrip';
import ConfirmArrival from './pages/ConfirmArrival';
import EmergencyScreen from './pages/EmergencyScreen';
import SafeScreen from './pages/SafeScreen';
import Contacts from './pages/Contacts';
import AcknowledgePage from './pages/AcknowledgePage';
import Nav from './components/Nav';
import './App.css';

export default function App() {
  return (
    <TripProvider>
      <BrowserRouter>
        <div className="app-shell">
          <Nav />
          <main className="app-main">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/setup" element={<SetupTrip />} />
              <Route path="/active" element={<ActiveTrip />} />
              <Route path="/confirm" element={<ConfirmArrival />} />
              <Route path="/emergency" element={<EmergencyScreen />} />
              <Route path="/safe" element={<SafeScreen />} />
              <Route path="/contacts" element={<Contacts />} />
              <Route path="/acknowledge/:alertId" element={<AcknowledgePage />} />
            </Routes>
          </main>
        </div>
      </BrowserRouter>
    </TripProvider>
  );
}
