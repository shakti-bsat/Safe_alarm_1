const nodemailer = require("nodemailer");
require("dotenv").config();

async function sendTest() {
    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    try {
        const info = await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: "prasanna10711@gmail.com",
            subject: "Test Email",
            text: "This is a test from SafeAlarm backend"
        });
        console.log("Email sent:", info.response);
    } catch (err) {
        console.log("EMAIL ERROR:", err);
    }
}

sendTest();
