// server.js
const express = require("express");
const nodemailer = require("nodemailer");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(express.static("public")); // frontend files

// ==========================
// Start Monitoring
// ==========================
app.post("/start", (req, res) => {
    console.log("Monitoring started");
    res.json({ message: "Monitoring started" });
});

// ==========================
// Mark Safe
// ==========================
app.post("/safe", (req, res) => {
    console.log("User marked safe");
    res.json({ message: "User marked safe" });
});

// ==========================
// Emergency Alert (Dynamic)
// ==========================
app.post("/alert", async (req, res) => {
    const { emails, lat, lon } = req.body; // emails = array of trusted contacts

    if (!emails || emails.length === 0) {
        return res.status(400).json({ error: "No recipient emails provided" });
    }

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: emails.join(","), // dynamic multiple recipients
        subject: "🚨 SafeAlarm Emergency Alert",
        text: `User did NOT confirm arrival.\n\nLocation:\nhttps://maps.google.com/?q=${lat},${lon}`
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("Email sent:", info.response);
        res.json({ message: "Alert sent successfully" });
    } catch (error) {
        console.log("EMAIL ERROR:", error);
        res.status(500).json({ error: "Email failed" });
    }
});

// ==========================
// Start Server
// ==========================
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
