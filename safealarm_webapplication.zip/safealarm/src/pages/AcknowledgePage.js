import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle, MapPin, ExternalLink } from 'lucide-react';
import { useTrip } from '../context/TripContext';
import './AcknowledgePage.css';

export default function AcknowledgePage() {
  const { alertId } = useParams();
  const { alerts, acknowledgeAlert, location } = useTrip();

  const alert = alerts.find(a => String(a.id) === alertId) || alerts[alerts.length - 1];

  useEffect(() => {
    if (alert && !alert.acknowledged) {
      acknowledgeAlert(alert?.id);
    }
  }, []); // eslint-disable-line

  return (
    <div className="ack-page fade-in">
      <div className="ack-icon">
        <CheckCircle size={48} />
      </div>
      <h1 className="ack-title">Alert Acknowledged</h1>
      <p className="ack-sub">Thank you for confirming. The system has logged your acknowledgment.</p>

      <div className="card">
        <div className="card-title">Alert Details</div>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-dim)', lineHeight: 1.6 }}>
          {alert?.reason || 'Safety alert triggered'}
        </p>
        <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 8, fontFamily: 'var(--font-mono)' }}>
          {alert?.time?.toLocaleString()}
        </p>
      </div>

      {location && (
        <div className="card">
          <div className="card-title"><MapPin size={12} /> Last Known Location</div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', marginBottom: 12 }}>
            {location.lat.toFixed(5)}, {location.lng.toFixed(5)}
          </p>
          <a href={`https://maps.google.com/?q=${location.lat},${location.lng}`} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm">
            <ExternalLink size={14} />
            Open in Google Maps
          </a>
        </div>
      )}

      <div className="ack-instruction card">
        <strong>Next steps:</strong>
        <ul style={{ marginTop: 8, paddingLeft: 18, color: 'var(--text-dim)', fontSize: '0.85rem', lineHeight: 2 }}>
          <li>Try calling the person directly</li>
          <li>If unreachable, proceed to their last known location</li>
          <li>Contact local authorities if needed</li>
        </ul>
      </div>
    </div>
  );
}
