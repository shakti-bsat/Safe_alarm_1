import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Clock, ArrowLeft, Zap } from 'lucide-react';
import { useTrip } from '../context/TripContext';
import './SetupTrip.css';

const QUICK_DURATIONS = [15, 30, 45, 60, 90];

export default function SetupTrip() {
  const { startTrip, contacts } = useTrip();
  const navigate = useNavigate();
  const [destination, setDestination] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [customDuration, setCustomDuration] = useState('');

  const handleStart = () => {
    const dur = customDuration ? parseInt(customDuration) : durationMinutes;
    if (!dur || dur < 1) return;
    startTrip({ destination: destination || 'Home', durationMinutes: dur });
    navigate('/active');
  };

  const now = new Date();
  const eta = new Date(now.getTime() + (customDuration || durationMinutes) * 60 * 1000);

  return (
    <div className="setup fade-in">
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate('/')}>
          <ArrowLeft size={16} /> Back
        </button>
        <h1 className="page-title">New Trip</h1>
        <p className="page-sub">Set your destination and expected arrival time</p>
      </div>

      <div className="card">
        <div className="card-title"><MapPin size={12} /> Destination</div>
        <input
          className="form-input"
          placeholder="e.g. Home, Apartment, Parents House"
          value={destination}
          onChange={e => setDestination(e.target.value)}
        />
      </div>

      <div className="card">
        <div className="card-title"><Clock size={12} /> Travel Duration</div>
        <div className="quick-durations">
          {QUICK_DURATIONS.map(d => (
            <button
              key={d}
              className={`duration-chip ${durationMinutes === d && !customDuration ? 'active' : ''}`}
              onClick={() => { setDurationMinutes(d); setCustomDuration(''); }}
            >
              {d}m
            </button>
          ))}
        </div>
        <div className="custom-duration-row">
          <input
            className="form-input"
            type="number"
            placeholder="Custom minutes..."
            value={customDuration}
            onChange={e => setCustomDuration(e.target.value)}
            min="1"
            max="480"
          />
        </div>
        <div className="eta-preview">
          <span className="eta-label">Estimated Arrival</span>
          <span className="eta-time">{eta.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      </div>

      <div className="card contacts-preview">
        <div className="card-title">Who will be alerted</div>
        {contacts.map(c => (
          <div key={c.id} className="contact-row">
            <div className="contact-avatar">{c.name[0]}</div>
            <div>
              <div className="contact-name">{c.name}</div>
              <div className="contact-meta">Tier {c.tier} • {c.relation}</div>
            </div>
            <span className={`badge badge-${c.tier === 1 ? 'info' : 'warn'}`}>T{c.tier}</span>
          </div>
        ))}
      </div>

      <button className="btn btn-primary start-btn" onClick={handleStart}>
        <Zap size={18} />
        Start Monitoring
      </button>

      <p className="disclaimer">
        Location access will be requested. You can opt out at any time during the trip.
      </p>
    </div>
  );
}
