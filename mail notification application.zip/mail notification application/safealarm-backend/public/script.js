let timer;

function startMonitoring() {

    const eta = document.getElementById("eta").value;

    fetch("/start", { method: "POST" });

    document.getElementById("status").innerText = "Monitoring Started...";

    timer = setTimeout(() => {
        document.getElementById("controls").style.display = "block";
        document.getElementById("status").innerText = "Confirm Arrival!";
    }, eta * 60000);
}

function markSafe() {
    fetch("/safe", { method: "POST" });
    clearTimeout(timer);
    document.getElementById("status").innerText = "Marked Safe.";
}

function sendAlert() {

    const email = document.getElementById("email").value;

    navigator.geolocation.getCurrentPosition(position => {

        fetch("/alert", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: email,
                lat: position.coords.latitude,
                lon: position.coords.longitude
            })
        })
        .then(res => res.json())
        .then(data => {
            document.getElementById("status").innerText = "Emergency Alert Sent!";
        });

    });
}
