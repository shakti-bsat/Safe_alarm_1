import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Trash2, ArrowLeft, UserCheck } from 'lucide-react';
import { useTrip } from '../context/TripContext';
import './Contacts.css';

export default function Contacts() {
  const { contacts, setContacts } = useTrip();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', phone: '', relation: '', tier: '1' });
  const [adding, setAdding] = useState(false);

  const addContact = () => {
    if (!form.name || !form.phone) return;
    setContacts(prev => [...prev, { id: Date.now(), ...form, tier: parseInt(form.tier) }]);
    setForm({ name: '', phone: '', relation: '', tier: '1' });
    setAdding(false);
  };

  const remove = (id) => setContacts(prev => prev.filter(c => c.id !== id));

  const tier1 = contacts.filter(c => c.tier === 1);
  const tier2 = contacts.filter(c => c.tier === 2);

  return (
    <div className="contacts-page fade-in">
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate('/')}>
          <ArrowLeft size={16} /> Back
        </button>
        <h1 className="page-title">Trusted Contacts</h1>
        <p className="page-sub">Tier 1 is alerted first. Tier 2 is escalated to if no acknowledgment in 3 minutes.</p>
      </div>

      {[
        { tier: 1, list: tier1, label: 'Tier 1 — Primary Contacts', color: 'info' },
        { tier: 2, list: tier2, label: 'Tier 2 — Escalation Contacts', color: 'warn' },
      ].map(({ tier, list, label, color }) => (
        <div key={tier} className="card">
          <div className="card-title">{label}</div>
          {list.length === 0 && <p className="empty-msg">No contacts added</p>}
          {list.map(c => (
            <div key={c.id} className="contact-item">
              <div className={`contact-avatar tier-${c.tier}`}>{c.name[0]}</div>
              <div className="contact-info">
                <div className="contact-name">{c.name}</div>
                <div className="contact-detail">{c.phone}{c.relation ? ` • ${c.relation}` : ''}</div>
              </div>
              <button className="delete-btn" onClick={() => remove(c.id)}>
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      ))}

      {adding ? (
        <div className="card add-form">
          <div className="card-title"><Plus size={12} /> New Contact</div>
          <div className="form-group">
            <label className="form-label">Name *</label>
            <input className="form-input" placeholder="Full name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Phone *</label>
            <input className="form-input" placeholder="+91 98765 43210" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Relation</label>
            <input className="form-input" placeholder="e.g. Sister, Manager, Friend" value={form.relation} onChange={e => setForm(f => ({ ...f, relation: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Alert Tier</label>
            <div className="tier-toggle">
              {['1', '2'].map(t => (
                <button key={t} className={`tier-btn ${form.tier === t ? 'active' : ''}`} onClick={() => setForm(f => ({ ...f, tier: t }))}>
                  Tier {t}
                </button>
              ))}
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn-primary btn-sm" onClick={addContact}>Add Contact</button>
            <button className="btn btn-ghost btn-sm" onClick={() => setAdding(false)}>Cancel</button>
          </div>
        </div>
      ) : (
        <button className="btn btn-ghost" onClick={() => setAdding(true)}>
          <Plus size={16} />
          Add Contact
        </button>
      )}

      <div className="card tier-explainer">
        <div className="card-title"><UserCheck size={12} /> Escalation Logic</div>
        <p className="explainer-text">
          When an alert is triggered, Tier 1 contacts receive an immediate message with your live location.
          If no acknowledgment is received within <strong>3 minutes</strong>, the system automatically escalates to Tier 2 contacts.
        </p>
      </div>
    </div>
  );
}
