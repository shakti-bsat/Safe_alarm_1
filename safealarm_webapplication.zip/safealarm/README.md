# 🛡️ SafeAlarm — Proactive Safety Monitoring App

A full-stack React web app for hackathon demo. SafeAlarm monitors commute arrivals and auto-escalates alerts if a user doesn't confirm safe arrival.

---

## ⚡ Quick Start (Under 10 Minutes)

### Prerequisites
- [Node.js 18+](https://nodejs.org/) installed
- VS Code (recommended)

### Step 1: Extract & Open
```bash
# Extract the zip, then open VS Code in the folder
cd safealarm
code .
```

### Step 2: Install Dependencies
Open the **VS Code Terminal** (`Ctrl + ~`) and run:
```bash
npm install
```
Wait ~60–90 seconds for packages to install.

### Step 3: Start the App
```bash
npm start
```

The app opens automatically at **http://localhost:3000**

---

## 🗺️ App Flow (Demo Guide)

### How to demo the full flow:

1. **Dashboard** — Home screen shows system status
2. **Start Trip** → Click "Start Trip Monitoring"
3. **Setup** → Set destination + duration (use **1–2 minutes** for demo)
4. **Active Trip** → Watch the countdown ring
   - You can hit **EMERGENCY** at any time to simulate panic
5. **ETA Expires** → Confirmation screen appears automatically
6. **Confirm Screen** — Three buttons:
   - ✅ **I'M SAFE** → Ends session, shows safe screen
   - ⏱️ **SNOOZE** → Extends by 5m → 3m → 2m (progressive)
   - 🚨 **EMERGENCY** → Dispatches alert immediately
7. **If no response after all snoozes** → Auto-escalates to Emergency
8. **Emergency Screen** → Shows:
   - Alert dispatched timeline
   - Simulated acknowledgment (click the demo button)
   - GPS location link (Google Maps)
   - Tier 1 / Tier 2 escalation status

### Contacts Page (`/contacts`)
- Add/remove trusted contacts
- Assign to Tier 1 (immediate) or Tier 2 (escalation after 3 min)

---

## 📁 Project Structure

```
safealarm/
├── public/
│   └── index.html              # HTML shell
├── src/
│   ├── App.js                  # Router + layout
│   ├── App.css                 # Shared component styles
│   ├── index.js                # Entry point
│   ├── index.css               # Global styles + animations
│   ├── context/
│   │   └── TripContext.js      # 🧠 All app state & logic
│   ├── components/
│   │   ├── Nav.js              # Top navigation bar
│   │   └── Nav.css
│   └── pages/
│       ├── Dashboard.js        # Home screen
│       ├── SetupTrip.js        # Trip configuration
│       ├── ActiveTrip.js       # Live countdown + ring
│       ├── ConfirmArrival.js   # 3-button confirmation screen
│       ├── EmergencyScreen.js  # Alert dispatched + timeline
│       ├── SafeScreen.js       # Trip summary on safe arrival
│       ├── Contacts.js         # Manage trusted contacts
│       └── AcknowledgePage.js  # Contact acknowledgment page
```

---

## 🧠 Core Logic (TripContext.js)

All business logic lives in `src/context/TripContext.js`:

| Feature | Implementation |
|---|---|
| Trip Activation | `startTrip()` stores start time, ETA, begins countdown |
| Countdown Timer | `useEffect` with `setInterval`, ticks every 1 second |
| ETA Lapse | When `secondsLeft === 0`, status → `CONFIRMING` |
| Progressive Snooze | Windows: 5min → 3min → 2min, tracked by `snoozeIndex` |
| Auto-Escalation | After final snooze, status → `EMERGENCY`, `dispatchAlert()` |
| Alert Dispatch | Creates alert object with location + contacts |
| Acknowledgment | `acknowledgeAlert()` marks alert + logs timestamp |
| Battery Simulation | `setInterval` drains `battery` state by 0.05% per 10s |
| GPS Location | `navigator.geolocation` with fallback coordinates |

---

## 🎯 Hackathon Metrics Demonstrated

| Metric | How Demonstrated |
|---|---|
| ETA lapse → alert < 2 min | Timer shows exact elapsed time on Emergency screen |
| 3-button confirmation | ConfirmArrival.js — Safe / Snooze / Emergency |
| Progressive snooze | 5m → 3m → 2m, with countdown bar |
| Auto-escalation | Triggers automatically after final snooze expires |
| Acknowledgment loop | Simulated 15s auto-ack + manual demo button |
| Tier 1 → Tier 2 escalation | Shows after 180s on Emergency screen |
| GPS location sharing | Google Maps link with real coordinates |
| Session log | Every action timestamped, visible on Safe + Dashboard |
| Battery monitoring | Live % in nav bar, drains during active session |

---

## 🔧 Customization

### Change snooze windows
In `src/context/TripContext.js`, line ~10:
```js
const SNOOZE_WINDOWS = [5 * 60, 3 * 60, 2 * 60]; // seconds
```

### Change auto-acknowledgment delay (demo)
In `dispatchAlert()` function:
```js
}, 15000); // 15 seconds in demo = simulates ~2.5 min in real life
```

### Connect real SMS (Twilio)
Replace the `dispatchAlert()` function body with a `fetch()` call to your backend API:
```js
await fetch('/api/send-alert', {
  method: 'POST',
  body: JSON.stringify({ contacts, location, reason }),
});
```

---

## 🚀 Build for Production

```bash
npm run build
```

Outputs to `build/` folder — deploy to Netlify, Vercel, or any static host.

---

## 📱 Mobile Testing

On same WiFi, open `http://<your-ip>:3000` on your phone.
Find your IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux).

---

## 🔐 Privacy & Data

- No data is sent to any server in this demo
- All state is in-memory (resets on page refresh)
- GPS coordinates only accessed with browser permission
- For production: implement session-based encrypted storage + 24hr auto-delete

---

*Built for SafeAlarm Hackathon Pilot — District X Night Shift Worker Safety Program*
