import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Shield, Clock } from 'lucide-react';
import { useTrip } from '../context/TripContext';
import './SafeScreen.css';

export default function SafeScreen() {
  const { startTime, etaTime, sessionLog, resetTrip } = useTrip();
  const navigate = useNavigate();

  const arrivedAt = new Date();
  const delay = etaTime ? Math.max(0, Math.round((arrivedAt - etaTime) / 1000)) : 0;

  const handleReset = () => {
    resetTrip();
    navigate('/');
  };

  return (
    <div className="safe-screen fade-in">
      <div className="safe-icon-wrap">
        <CheckCircle size={48} className="safe-icon" />
        <span className="s-ring" />
      </div>

      <h1 className="safe-title">You're Safe!</h1>
      <p className="safe-sub">Trusted contacts have been notified of your safe arrival.</p>

      <div className="card safe-stats">
        <div className="safe-stat">
          <div className="ss-val">
            {startTime ? startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
          </div>
          <div className="ss-label">Trip Started</div>
        </div>
        <div className="safe-stat">
          <div className="ss-val">
            {etaTime ? etaTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
          </div>
          <div className="ss-label">ETA Was</div>
        </div>
        <div className="safe-stat">
          <div className="ss-val" style={{ color: delay > 0 ? 'var(--warn)' : 'var(--safe)' }}>
            {delay > 0 ? `+${delay}s` : 'On Time'}
          </div>
          <div className="ss-label">Variance</div>
        </div>
      </div>

      {sessionLog.length > 0 && (
        <div className="card">
          <div className="card-title"><Clock size={12} /> Trip Log</div>
          {sessionLog.map((l, i) => (
            <div key={i} className="log-entry">
              <span className="log-time">{l.time.toLocaleTimeString()}</span>
              <span className="log-msg">{l.msg}</span>
            </div>
          ))}
        </div>
      )}

      <button className="btn btn-safe" onClick={handleReset} style={{ marginTop: 8 }}>
        <Shield size={18} />
        Start New Trip
      </button>
    </div>
  );
}
