import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, Users, Home } from 'lucide-react';
import { useTrip, TRIP_STATUS } from '../context/TripContext';
import './Nav.css';

export default function Nav() {
  const loc = useLocation();
  const { status, battery } = useTrip();

  const isActive = (path) => loc.pathname === path;
  const showNav = [TRIP_STATUS.IDLE, TRIP_STATUS.SAFE].includes(status) ||
    !['/', '/setup', '/contacts'].includes(loc.pathname) ? false : true;

  return (
    <nav className="nav">
      <div className="nav-inner">
        <Link to="/" className="nav-brand">
          <Shield size={20} />
          <span>SafeAlarm</span>
        </Link>

        <div className="nav-status">
          <span className="battery-indicator">
            <span className={`battery-bar ${battery < 20 ? 'low' : ''}`} style={{ width: `${battery}%` }} />
          </span>
          <span className="battery-text">{Math.round(battery)}%</span>
        </div>

        <div className="nav-links">
          <Link to="/" className={`nav-link ${isActive('/') ? 'active' : ''}`}>
            <Home size={16} />
          </Link>
          <Link to="/contacts" className={`nav-link ${isActive('/contacts') ? 'active' : ''}`}>
            <Users size={16} />
          </Link>
        </div>
      </div>
    </nav>
  );
}
