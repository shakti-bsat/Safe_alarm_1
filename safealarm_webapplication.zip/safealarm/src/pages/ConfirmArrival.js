import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Clock, AlertOctagon } from 'lucide-react';
import { useTrip, TRIP_STATUS } from '../context/TripContext';
import './ConfirmArrival.css';

function formatSec(s) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return m > 0 ? `${m}m ${String(sec).padStart(2,'0')}s` : `${sec}s`;
}

export default function ConfirmArrival() {
  const { status, confirmSafe, snooze, triggerEmergency, snoozeIndex, snoozeSecondsLeft, SNOOZE_WINDOWS } = useTrip();
  const navigate = useNavigate();

  useEffect(() => {
    if (status === TRIP_STATUS.IDLE) navigate('/');
    if (status === TRIP_STATUS.ACTIVE) navigate('/active');
    if (status === TRIP_STATUS.EMERGENCY || status === TRIP_STATUS.ESCALATED) navigate('/emergency');
    if (status === TRIP_STATUS.SAFE) navigate('/safe');
  }, [status, navigate]);

  const isSnoozed = status === TRIP_STATUS.SNOOZED;
  const snoozeWindow = SNOOZE_WINDOWS[snoozeIndex] || 60;
  const snoozeProgress = isSnoozed ? snoozeSecondsLeft / snoozeWindow : 0;
  const isLastChance = snoozeIndex >= SNOOZE_WINDOWS.length - 1 && isSnoozed;

  return (
    <div className="confirm fade-in">
      <div className={`confirm-pulse ${isLastChance ? 'last-chance' : ''}`}>
        <div className="pulse-icon">
          <AlertOctagon size={36} />
          <span className="p-ring" />
          <span className="p-ring r2" />
        </div>
      </div>

      <h1 className="confirm-title">
        {isSnoozed ? 'Extended Time Running Out' : 'Are you safe?'}
      </h1>
      <p className="confirm-sub">
        {isSnoozed
          ? `Snooze window ${snoozeIndex + 1} of ${SNOOZE_WINDOWS.length}. Alert will auto-send if no response.`
          : 'Your ETA has lapsed. Please confirm your status immediately.'}
      </p>

      {isSnoozed && (
        <div className="snooze-timer-wrapper">
          <div className="snooze-bar-bg">
            <div
              className={`snooze-bar-fill ${isLastChance ? 'last' : ''}`}
              style={{ width: `${snoozeProgress * 100}%` }}
            />
          </div>
          <div className="snooze-remaining">
            Auto-alert in <span>{formatSec(snoozeSecondsLeft)}</span>
          </div>
        </div>
      )}

      <div className="confirm-actions">
        <button
          className="confirm-btn safe"
          onClick={() => { confirmSafe(); navigate('/safe'); }}
        >
          <CheckCircle size={28} />
          <span className="cb-label">I'M SAFE</span>
          <span className="cb-sub">Confirm safe arrival</span>
        </button>

        {!isSnoozed && snoozeIndex < SNOOZE_WINDOWS.length && (
          <button
            className="confirm-btn snooze"
            onClick={snooze}
          >
            <Clock size={24} />
            <span className="cb-label">SNOOZE</span>
            <span className="cb-sub">Need {formatSec(SNOOZE_WINDOWS[snoozeIndex])} more</span>
          </button>
        )}

        <button
          className="confirm-btn danger"
          onClick={() => { triggerEmergency(); navigate('/emergency'); }}
        >
          <AlertOctagon size={24} />
          <span className="cb-label">EMERGENCY</span>
          <span className="cb-sub">Alert contacts now</span>
        </button>
      </div>

      {isLastChance && (
        <div className="last-chance-banner">
          ⚠️ Final warning — contacts will be alerted automatically
        </div>
      )}
    </div>
  );
}
